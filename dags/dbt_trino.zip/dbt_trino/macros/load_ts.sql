{% macro load_ts() %} current_timestamp {% endmacro %}
